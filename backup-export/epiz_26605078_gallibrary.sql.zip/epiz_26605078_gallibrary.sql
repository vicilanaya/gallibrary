-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql306.epizy.com
-- Generation Time: Oct 31, 2026 at 07:02 PM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epiz_26605078_gallibrary`
--

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE `resources` (
  `id` int(10) UNSIGNED NOT NULL,
  `section_id` int(10) UNSIGNED NOT NULL COMMENT 'sections.id (pick the section row of the same language)',
  `name` varchar(255) NOT NULL,
  `link` varchar(2048) NOT NULL,
  `description` text DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT 'lower numbers first within the section'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `resources`
--

INSERT INTO `resources` (`id`, `section_id`, `name`, `link`, `description`, `sort_order`) VALUES
(1, 1, 'Daniel Kids', 'https://www.danielkids.org/', 'Daniel offers an array of quality, efficient and effective mental\n				health and social service programs aimed at enhancing the lives of children and\n				families. Whether it be a therapeutic foster home for an abused child, independent\n				living services for a homeless adolescent, intervention services for an adolescent\n				on the path of juvenile delinquency or treatment for an emotionally disturbed,\n				behaviorally disruptive child, Daniel’s quality continuum of care can help meet the\n				needs of the children and families in the community it serves.', 10),
(2, 1, 'Daniel Kids: Florida\'s Independent Living Resource Center', 'https://www.danielkids.org/our-programs/floridas-i-l-resource-center/', 'Independent Living services for transitioning young adults\n				include Extended Foster Care (EFC), Postsecondary Education Services and Support\n				(PESS), and Aftercare Services.', 20),
(3, 1, 'Gulf Coast Jewish Family and Community Services', 'https://gulfcoastjewishfamilyandcommunityservices.org/', 'Case management agency. The agency’s mission is to provide\n				essential human services to individuals and families in time of need. We offer\n				extensive counseling, family support services, food, shelter and human kindness to\n				those in crisis. These services are provided throughout the State of Florida in 32\n				counties.', 30),
(4, 1, 'Department of Children and Families (DCF)', 'https://www.myflfamilies.com/', 'DCF programs include: abuse hotline, ACCESS Florida, adoption,\n				adult protective services, child care, child welfare, community-based care, domestic\n				violence, foster care, homelessness, mental health, refugee services, substance\n				abuse', 40),
(5, 1, 'DCF - Independent Living Services', 'https://www.myflfamilies.com/service-programs/independent-living/', 'Services for Transitioning Youth and Young Adults', 50),
(6, 1, 'DCF - Independent Living', 'https://www.myflfamilies.com/service-programs/independent-living/links.shtml', 'Other resources and useful links', 60),
(7, 1, 'Keys to Independence', 'http://keystoindependencefl.com/', 'This program will reimburse youth and caregivers for the costs\n				associated with driver’s education, driver’s licenses and other costs related to\n				getting a driver’s license as well as motor vehicle insurance.', 70),
(8, 1, 'Embrace Families', 'https://embracefamilies.org/', 'Community based care that works with a collaborative network of\n				state, local and private partners to ensure that every child in our community has a\n				safe and stable home.', 80),
(9, 2, 'Daniel Kids', 'https://www.danielkids.org/', 'Daniel ofrece una variedad de programas de servicios sociales y\n				servicios de salud mental eficientes, efectivos, y de calidad dirigidos a mejorar\n				las vidas de niños y familias. Sea un hogar de acogida terapéutica para un niño\n				abusado, servicios de vida independiente para un adolescente indigente, servicios de\n				intervención para un adolescente de camino a la delincuencia, o tratamiento para un\n				niño emocionalmente perturbado o de conducta perturbadora, el cuidado de calidad de\n				Daniel puede ayudar a satisfacer las necesidades de niños y familias en la\n				comunidad.', 10),
(10, 2, 'Daniel Kids: el centro de recursos de vida independiente de Florida', 'https://www.danielkids.org/our-programs/floridas-i-l-resource-center/', 'Los servicios de vida independiente para la transición de adultos\n				jóvenes incluyen hogar de acogida extendido, servicios y apoyo de educación\n				secundaria, y servicios de post-tratamiento.', 20),
(11, 2, 'Gulf Coast Jewish Family and Community Services', 'https://gulfcoastjewishfamilyandcommunityservices.org/', 'Agencia de manejo de casos. La misión de la agencia es proveer\n				servicios humanos esenciales para individuos y familias en tiempos de necesidad.\n				Ofrecemos consejería extensiva, servicios de apoyo a la familia, comida, albergue y\n				bondad humana a personas en crisis. Estos servicios se proveen a través del estado\n				de Florida en 32 condados.', 30),
(12, 2, 'Departamento de Niños y Familias (DCF)', 'https://www.myflfamilies.com/', 'Los programas del departamento incluyen: línea directa de abuso,\n				ACCESS Florida (Conexión Comunitaria Automatizada para Autosuficiencia Económica),\n				adopción, servicios de protección de adultos, cuidado de niños, servicios sociales\n				para menores, atención comunitaria, violencia doméstica, hogares de acogida,\n				indigencia, salud mental, servicios para refugiados, abuso de sustancias.', 40),
(13, 2, 'DCF - Servicios de Vida Independiente', 'https://www.myflfamilies.com/service-programs/independent-living/', 'Servicios de transición para menores y adultos jóvenes', 50),
(14, 2, 'DCF - Vida Independiente', 'https://www.myflfamilies.com/service-programs/independent-living/links.shtml', 'Otros recursos y enlaces útiles', 60),
(15, 2, 'Secretos Hacia la Independencia', 'http://keystoindependencefl.com/', 'Este programa reembolsa a menores y sus cuidadores los costos\n				asociados con educación de conductores, licencias de conducir y otros costos\n				relacionados a la obtención de licencias de conducir y seguro de vehículos de motor.', 70),
(16, 2, 'Embrace Families', 'https://embracefamilies.org/', 'Atención comunitaria que colabora con una red entre asociados\n				privados, locales y del estado para asegurar que cada niño en nuestra comunidad\n				tenga un hogar estable y seguro.', 80),
(17, 3, 'UStrive', 'https://www.ustrive.com/', 'Find a mentor to help guide the college application process.', 10),
(18, 3, 'Get your GED (General Education Development/Diploma)', 'http://fatdec.com/', 'Florida Adult and Technical Distance Education Consortium\n				(FATDEC)', 20),
(19, 3, 'FAFSA', 'https://studentaid.ed.gov/sa/fafsa', 'Free Application for Federal Student Aid (FAFSA)', 30),
(20, 3, 'Osceola County Public Schools (OCPS)', 'https://www.osceolaschools.net/', 'The School District of Osceola County, Florida', 40),
(21, 3, 'Florida Virtual School (FLVS)', 'https://flvs.net/', 'Online public school', 50),
(22, 3, 'Osceola Technical College (oTECH)', 'https://otec.osceolaschools.net/', 'Career and technical education and dual enrollment', 60),
(23, 3, 'Accelerated Skills Training Programs', 'https://net1.valenciacollege.edu/continuing-education/accelerated-skills-training-programs/', 'Valencia College’s Accelerated Skills Training Programs focus on\n				intensive, hands-on training designed to help you enter a new career field or\n				advance your current skillset. You’ll have the opportunity to earn\n				industry-recognized credentials, train in essential workplace skills and receive job\n				placement support.', 70),
(24, 3, 'District Postsecondary Institutions', 'http://www.fldoe.org/academics/career-adult-edu/dist-ps-instit.stml', 'Florida Department of Education', 80),
(25, 3, 'Apprenticeship Toolbox', 'http://www.fldoe.org/academics/career-adult-edu/apprenticeship-programs/apprenticeship-toolbox/various-links.stml', 'Florida Department of Education', 90),
(26, 3, 'The Florida College System (FCS)', 'https://www.floridacollegesystem.com/', '28 colleges; low-cost, high-quality certificate and degree\n				programs', 100),
(27, 3, 'Online Programs', 'https://www.floridacollegesystem.com/students/programs/online_programs.aspx', 'Distance learning courses and degrees offer students in Florida\n				College System (FCS) institutions flexible and affordable access to higher\n				education, providing students with multiple options.', 110),
(28, 3, 'State University System of Florida', 'https://www.flbog.edu/', '12 institutions make it the second largest public university\n				system in the country', 120),
(29, 3, 'GradSchools.com', 'https://www.gradschools.com/', 'Search master\'s, doctorate, PhDs, and graduate certificate\n				programs', 130),
(30, 4, 'UStrive', 'https://www.ustrive.com/', 'Encuentre un mentor que le ayude através del proceso de solicitud\n				de ingreso a la universidad.', 10),
(31, 4, 'Obtenga su GED (General Education Development/Diploma)', 'http://fatdec.com/', 'Florida Adult and Technical Distance Education Consortium\n				(FATDEC)', 20),
(32, 4, 'FAFSA', 'https://studentaid.ed.gov/sa/es/fafsa', 'Solicitud Gratuita de Ayuda Federal para Estudiantes (FAFSA)', 30),
(33, 4, 'Escuelas públicas del Condado de Osceola (OCPS)', 'https://www.osceolaschools.net/', 'Distrito Escolar del Condado de Osceola', 40),
(34, 4, 'Escuela Virtual de Florida (FLVS)', 'https://flvs.net/', 'Escuela pública en línea', 50),
(35, 4, 'Colegio Técnico de Osceola (oTECH)', 'https://otec.osceolaschools.net/', 'Educación técnica y de carrera y matrícula doble', 60),
(36, 4, 'Programas Acelerados de Adiestramiento en Destrezas', 'https://net1.valenciacollege.edu/continuing-education/accelerated-skills-training-programs/', 'Los Programas Acelerados de Adiestramiento en Destrezas de\n				Valencia College se enfocan en entrenamiento prácticos e intensivos diseñados para\n				ayudarle a entrar a una carrera nueva o avanzar su colección actual de destrezas.\n				Usted tendrá la oportunidad de ganarse credenciales reconocidas en la industria,\n				adiestrarse en destrezas esenciales en el lugar de trabajo y recibir apoyo en su\n				colocación.', 70),
(37, 4, 'Instituciones Terciarias de Distrito', 'http://www.fldoe.org/academics/career-adult-edu/dist-ps-instit.stml', 'Departamento de Educación de Florida', 80),
(38, 4, 'Caja de herrameintas para aprendices', 'http://www.fldoe.org/academics/career-adult-edu/apprenticeship-programs/apprenticeship-toolbox/various-links.stml', 'Departamento de Educación de Florida', 90),
(39, 4, 'Sistema de Colegios de Florida (FCS)', 'https://www.floridacollegesystem.com/', '28 collegios; programas de grados y certificados económicos y de\n				alta calidad', 100),
(40, 4, 'Programas en Línea', 'https://www.floridacollegesystem.com/students/programs/online_programs.aspx', 'Cursos y grados por aprendizaje a distancia ofrecen a estudiantes\n				de las instituciones del Sistema de Colegios de Florida (FCS) acceso flexible y\n				económico a educación superior, proveyendo a esos estudiantes con opciones\n				múltiples.', 110),
(41, 4, 'Sistema Universitario del Estado de Florida', 'https://www.flbog.edu/', '12 instituciones lo hacen el segundo sistema universitario\n				público más grande del país', 120),
(42, 4, 'GradSchools.com', 'https://www.gradschools.com/', 'Buscador de programas de maestría, doctorado, PhDs y certificados\n				graduados', 130),
(43, 5, 'Internal Revenue Service', 'https://www.irs.gov/filing', 'File your tax return', 10),
(44, 5, 'Types of Federal Student Aid', 'https://studentaid.ed.gov/sa/types', 'Learn about grants, loans, and work-study jobs and how they can\n				help fund your education.', 20),
(45, 5, 'Get help with bills', 'https://www.usa.gov/help-with-bills', 'Learn about government programs to help pay for phone bills,\n				medical bills, and other expenses. You can also learn how to apply for temporary\n				assistance.', 30),
(46, 5, 'ACCESS Florida', 'https://www.myflfamilies.com/service-programs/access/map.shtml', 'The Florida Department of Children and Families Automated\n				Community Connection to Economic Self Sufficiency (ACCESS). The ACCESS Florida\n				system allows customers to connect with their public assistance information 24/7,\n				through the online application and MyACCESS Account. The Economic Self-Sufficiency\n				Program helps to promote strong and economically self-sufficient communities by\n				determining eligibility for food, cash and medical assistance for individuals and\n				families on the road to economic recovery.', 40),
(47, 5, 'Get your free annual credit reports', 'https://www.ftc.gov/faq/consumer-protection/get-my-free-credit-report', 'You\'re entitled to one free copy of your credit report every 12\n				months from each of the three nationwide credit reporting companies.', 50),
(48, 5, 'Government Benefits', 'https://www.usa.gov/benefits', 'Get information on government programs that may help you pay for\n				food, housing, health care, and other basic living expenses. Find out about\n				eligibility requirements for programs like food stamps, welfare, and Medicaid, and\n				how to apply for them.', 60),
(49, 5, 'Government Benefit Finder', 'https://www.benefits.gov/', 'Get help finding federal benefits you may be eligible for in the\n				United States.', 70),
(50, 5, 'Get help paying for child care', 'https://www.acf.hhs.gov/occ/resource/ccdf-grantee-state-and-territory-contacts', 'State and Territory Child Care and Development Fund\n				Administrators', 80),
(51, 5, 'Women, Infants & Children (WIC)', 'http://osceola.floridahealth.gov/programs-and-services/clinical-and-nutrition-services/wic/index.html', 'A federal assistance program of the Food and Nutrition Service of\n				the United States Department of Agriculture for healthcare and nutrition of\n				low-income pregnant women, breastfeeding women, and children under the age of five.', 90),
(52, 5, 'The Florida Child Support Program', 'https://childsupport.floridarevenue.com/', 'The Child Support Program\'s purpose is to help children get the\n				financial support they need when it is not received from one or both parents. The\n				services are available even if a parent lives in another state or country. The\n				Florida Department of Revenue provides child support services in all but two Florida\n				counties. We partner with the State Attorney\'s Office for services in Miami-Dade\n				County and the Manatee County Clerk of Court for services in Manatee County.', 100),
(53, 5, 'MyMoney.gov', 'https://www.mymoney.gov', 'This website is a product of the Congressionally chartered\n				Federal Financial Literacy and Education Commission, which is made up of more than\n				20 Federal entities that are coordinating and collaborating to strengthen financial\n				capability and increase access to financial services for all Americans.', 110),
(54, 5, 'The Emergency Food Assistance Program (TEFAP)', 'https://www.fdacs.gov/Food-Nutrition/Nutrition-Programs/The-Emergency-Food-Assistance-Program-TEFAP', 'TEFAP is a U.S. Department of Agriculture (USDA) food\n				distribution program that provides nutritious, high-quality foods to low-income\n				households, distributes food to participating food banks, food pantries, soup\n				kitchens and other feeding sites, and supplies food to be served to individual\n				households or as prepared meals in a community setting for eligible recipients.', 120),
(55, 5, 'Tax Refunds, Internal Revenue Service (IRS)', 'https://www.irs.gov/refunds', 'Check your tax refund status', 130),
(56, 5, 'Investor.gov', 'https://www.investor.gov/', 'Online resource from the U.S. Securities and Exchange\n				Commission’s (SEC) Office of Investor Education and Advocacy to help you make sound\n				investment decisions and avoid fraud.', 140),
(57, 6, 'Servicio de Rentas Internas', 'https://www.irs.gov/es/spanish', 'Reintegro de impuestos', 10),
(58, 6, 'Tipos de ayuda económica federal para estudiantes', 'https://studentaid.ed.gov/sa/types', 'Becas y subvenciones, fondos del Programa de Estudio y Trabajo,\n				préstamos y becas de estudio ayudan a que la universidad o el instituto profesional\n				sean más accesibles.', 20),
(59, 6, 'Obtén ayuda con el pago de facturas', 'https://www.usa.gov/espanol/pago-facturas', 'Ayuda con el pago de facturas de teléfono, servicios, gastos\n				médicos y asistencia para familias necesitadas.', 30),
(60, 6, 'ACCESS Florida', 'https://www.myflfamilies.com/service-programs/access/map.shtml', 'La Conexión a la Comunidad Automatizada para la Autosuficiencia\n				Económica (ACCESS) del Departamento de Niños y Familias de Florida. El sistema de\n				ACCESS Florida permite conectar a la clientela con su información de asistencia\n				pública 24/7, a través de la aplicación en línea y de la cuenta MyACCESS. El\n				Programa de Autosuficiencia Económica ayuda a promover comunidades fuertes y\n				económicamente autosuficientes al determinar elegibilidad para alimentos, asistencia\n				medica y de dinero para individuos y familias de camino a la recuperación económica.', 40),
(61, 6, 'Solicite su informe de crédito gratuito', 'https://www.consumidor.ftc.gov/articulos/s0155-informes-de-credito-gratuitos', 'La Ley de Informe Imparcial de Crédito requiere que, a su pedido,\n				cada una de las compañías de informes de los consumidores a nivel nacional —\n				Equifax, Experian y TransUnion — le provea cada 12 meses una copia gratuita de su\n				informe de crédito.', 50),
(62, 6, 'Programas de beneficios sociales del Gobierno', 'https://www.usa.gov/espanol/programas-sociales', 'Información sobre programas gubernamentales que pueden ayudarlo a\n				pagar por alimentos, vivienda y atención médica, entre otros. Averigüe los\n				requisitos de elegibilidad para programas como cupones de alimentos, asistencia\n				social y Medicaid, y cómo solicitarlos.', 60),
(63, 6, 'Buscador de Beneficios', 'https://www.benefits.gov/es/', 'Comience el cuestionario para encontrar los beneficios adecuados\n				para usted.', 70),
(64, 6, 'Obtén ayuda para pagar el cuido de niños', 'https://www.acf.hhs.gov/occ/resource/ccdf-grantee-state-and-territory-contacts', 'Administradores del Fondo Estatal y de Territorios para el\n				Cuidado de Niños y el Desarrollo', 80),
(65, 6, 'Programa para Mujeres, Infantes y Niños (WIC)', 'http://osceola.floridahealth.gov/programs-and-services/clinical-and-nutrition-services/wic/index.html', 'Un programa de asistencia federal del Servicio de Alimentos y\n				Nutrición del Departamento de Agricultura de Estados Unidos para la atención médica\n				y nutrición de las mujeres embarazadas de bajos ingresos, mujeres amamantando y\n				niños menores de 5 años.', 90),
(66, 6, 'Programa de Manutención de Menores de Florida', 'https://childsupport.floridarevenue.com/', 'El propósito del Programa de Manutención de Menores es ayudar a\n				los niños a obtener el apoyo financiero que necesitan cuando no lo reciben de uno u\n				ambos padres. Los servicios están disponibles aún si un padre vive en otro estado u\n				otro país. El Departamento de Rentas de Florida provee servicios de manutención de\n				menores en 65 de los 67 condados en el estado, y se asocia con la Fiscalía Estatal\n				para los servicios en el condado de Miami-Dade y con la Oficina del Secretario del\n				Juzgado para los servicios del Condado de Manatee.', 100),
(67, 6, 'MyMoney.gov', 'https://www.mymoney.gov/es/Pages/default.aspx', 'Este sitio web es un producto de la Comisión Federal de Educación\n				Financiera que fue creado por el Congreso, y que se compone de más de 20 entidades\n				federales que están coordinando y colaborando para fortalecer la capacidad\n				financiera y aumentar el acceso a los servicios financieros para todos los\n				Americanos.', 110),
(68, 6, 'El Programa de Asistencia Alimentaria de Emergencia (TEFAP)', 'https://www.fdacs.gov/Food-Nutrition/Nutrition-Programs/The-Emergency-Food-Assistance-Program-TEFAP', 'El Programa de Asistencia Alimentaria de Emergencia (TEFAP) es un\n				programa de distribución de comida del Departamento de Agricultura de Estados Unidos\n				(USDA) que provee alimentos nutritivos y de alta calidad a hogares de bajos\n				ingresos, distribuye comida a bancos de alimentos, almacenes, comedores comunitarios\n				y otros sitios de alimentación participantes. El programa también suministra\n				alimentos listos para servirse en hogares individuales o como comidas preparadas a\n				niveles comunitarios para recipientes eligibles.', 120),
(69, 6, 'Reintegro de Impuestos, Internal Revenue Service (IRS)', 'https://www.irs.gov/refunds', 'Verifique el estatus de su reintegro de impuestos', 130);
INSERT INTO `resources` (`id`, `section_id`, `name`, `link`, `description`, `sort_order`) VALUES
(70, 6, 'Investor.gov', 'https://www.investor.gov/espanol', 'Recurso educativo en línea para inversionistas, publicado por la\n				SEC. Aquí podrá encontrar alertas informativas para los inversionistas y\n				publicaciones acerca de una amplia gama de temas, incluyendo diferentes productos de\n				inversión, maneras de evitar el fraude y recomendaciones para la selección de un\n				profesional financiero.', 140),
(71, 7, 'CareerSource Central Florida', 'http://careersourcecentralflorida.com/', 'CareerSource connects employers to job seekers in Lake, Orange,\n				Osceola, Seminole and Sumter counties, provide worker resources and training, and\n				prepare Central Florida residents for careers which meet local businesses’ needs.', 10),
(72, 7, 'Goodwill Job Connection', 'https://goodwilljobconnection.org/', 'Goodwill provides training, English classes, job fairs, and\n				employment services.', 20),
(73, 7, 'Jobs Partnership of Florida', 'https://www.jobspartnership.org/', 'The Jobs Partnership of Florida is able to offer LifeWorks\n				Training, Career Pathways, Community Resource Fairs, Career Fairs, the Job\n				Connection website, educational opportunities, mentorship and other programs and\n				resources.', 30),
(74, 7, 'State of Florida Department of Economic Opportunity', 'https://www.floridajobs.org/', 'Reemployment assistance, business growth, workforce', 40),
(75, 7, 'Job Corps', 'https://www.jobcorps.gov/', 'Job Corps is the largest free residential education and job\n				training program for young adults ages 16-24.', 50),
(76, 7, 'Labor Laws and Issues', 'https://www.usa.gov/labor-laws', 'Learn about some important employment laws and issues.', 60),
(77, 7, 'Unemployment Help', 'https://www.usa.gov/unemployment', 'Learn how to apply for unemployment benefits, workers’\n				compensation, welfare or temporary assistance, and other programs and services that\n				can help if you lose your job.', 70),
(78, 7, 'Occupational Outlook Handbook (OOH) - U.S. Bureau of Labor Statistics', 'https://www.bls.gov/ooh/', 'The Occupational Outlook Handbook (OOH) is a career resource\n				offering information on the hundreds of occupations that provide the majority of\n				jobs in the United States. Each occupational profile describes the typical duties\n				performed by the occupation, the work environment of that occupation, the typical\n				education and training needed to enter the occupation, the median pay for workers in\n				the occupation, and the job outlook over the coming decade for that occupation. Each\n				profile is in a standard format that makes it easy to compare occupations, such as\n				by projected employment change.', 80),
(79, 7, 'City of Kissimmee', 'https://www.kissimmee.org/departments/human-resources-risk-management/employment-opportunities', 'Employment opportunities', 90),
(80, 7, 'City of Saint Cloud', 'https://www.governmentjobs.com/careers/stcloud', 'Job opportunities', 100),
(81, 7, 'Osceola County Job Center', 'https://www.governmentjobs.com/careers/osceola', 'Osceola County’s Online Employment Center', 110),
(82, 7, 'State of Florida Careers - PeopleFirst', 'https://jobs.myflorida.com/', 'Search for a career in one of the many locations in Florida.', 120),
(83, 7, 'USAJobs', 'https://www.usajobs.gov/', 'Find your fit in the federal government', 130),
(84, 8, 'CareerSource de Florida Central', 'http://careersourcecentralflorida.com/', 'CareerSource pone en contacto empleadores y solicitantes de\n				empleo en los condados de Lake, Orange, Osceola, Seminole y Sumter, proveen a los\n				trabajadores recursos y entrenamiento, y preparan a los residentes de la Florida\n				Central para carreras que satisfacen las necesidades de las empresas locales.', 10),
(85, 8, 'Goodwill Job Connection', 'https://goodwilljobconnection.org/', 'Goodwill provee entrenamiento, clases de inglés, ferias de empleo\n				y servicios de empleo.', 20),
(86, 8, 'Sociedad de Trabajos de Florida', 'https://www.jobspartnership.org/', 'La Sociedad de Trabajos de Florida ofrece Entrenamiento\n				LifeWorks, Senderos de Carrera, Ferias de Recursos Comunitarios, Ferias de Trabajo,\n				el sitio web de Conexión de Trabajo, oportunidades educacionales, mentoría y otros\n				programas y recursos.', 30),
(87, 8, 'Departamento de Oportunidad Económica de Florida', 'http://www.floridajobs.org/espanol', 'Asistencia para el reempleo, desarrollo empresarial, fuerza\n				laboral', 40),
(88, 8, 'Job Corps', 'https://www.jobcorps.gov/es', 'Job Corps es el mayor programa sin costo de educación residencial\n				y capacitación laboral para adultos jóvenes de 16 a 24 años de edad.', 50),
(89, 8, 'Leyes y Asuntos Laborales', 'https://www.usa.gov/labor-laws', 'Aprenda sobre algunos leyes y asuntos laborales importantes', 60),
(90, 8, 'Beneficios por desempleo', 'https://www.usa.gov/espanol/desempleo', 'Comience el proceso para recibir ayuda con los beneficios del\n				seguro de desempleo, capacitación laboral y para encontrar un trabajo.', 70),
(91, 8, 'Manual de Pronóstico Ocupacional (OOH) - Agencia de Estadísticas\n				Laborales de Estados Unidos', 'https://www.bls.gov/ooh/', 'El Manual de Pronóstico Ocupacional (OOH) es un recurso de\n				carrera que ofrece información sobre los cientos de ocupaciones que proveen la\n				mayoría de los trabajos en Estados Unidos. Cada perfil ocupacional describe los\n				deberes típicos de la ocupación, el ambiente laboral de la ocupación, la educación y\n				entrenamiento típicos necesarios para entra a la ocupación, la paga mediana de los\n				trabajadores en la ocupación, y el pronóstico de la ocupación en la próxima década.\n				Cada perfil esta en un formato estándar que hace fácil el comparar ocupaciones.', 80),
(92, 8, 'Ciudad de Kissimmee', 'https://www.kissimmee.org/departments/human-resources-risk-management/employment-opportunities', 'Oportunidades de empleo', 90),
(93, 8, 'Ciudad de Saint Cloud', 'https://www.governmentjobs.com/careers/stcloud', 'Oportunidades de trabajo', 100),
(94, 8, 'Centro de Empleo del Condado de Osceola', 'https://www.governmentjobs.com/careers/osceola', 'Centro de empleo en línea del Condado de Osceola', 110),
(95, 8, 'Carreras con el Estado de Florida - PeopleFirst', 'https://jobs.myflorida.com/', 'Busque una carrera en una de nuestras muchas localidades.', 120),
(96, 8, 'USAJobs', 'https://www.usajobs.gov/', 'Encuentre el trabajo adecuado en el gobierno federal', 130),
(97, 9, 'DAREBEE', 'https://darebee.com/', 'Fitness Made Easy - an independent global fitness resource', 10),
(98, 9, 'Health Insurance Marketplace', 'https://www.healthcare.gov/', 'The official site of the Health Insurance Marketplace. The\n				Marketplace is a new way to find health coverage that fits your budget and meets\n				your needs. With one application, you can see all your options and enroll.', 20),
(99, 9, 'STD Clinic at the Florida Department of Health in Osceola County', 'http://osceola.floridahealth.gov/programs-and-services/infectious-disease-services/std/index.html', 'The Florida Department of Health in Osceola County\'s STD clinic\n				offers services at a reasonable and/or no cost basis to adults and adolescents,\n				regardless of their citizenship status. Clinical services are provided for all\n				clients including adolescents who are assured confidential STD clinical services by\n				Florida Law.', 30),
(100, 9, 'PlannedParenthood', 'https://www.plannedparenthood.org/', 'Get care and answers about pregnancy, birth control, emergency\n				contraception, STDs, and abortion.', 40),
(101, 9, 'Disability Services', 'https://www.usa.gov/disability-services', 'Find information for people with disabilities, such as: benefits\n				and insurance, caregiver support, financial assistance and support services,\n				government and local disability programs, jobs and education, veterans disability\n				benefits, and your legal disability rights.', 50),
(102, 9, 'The Florida Department of Health', 'http://osceola.floridahealth.gov/', 'The Florida Department of Health works to protect, promote &\n				improve the health of all people in Florida through integrated state, county, &\n				community efforts.', 60),
(103, 9, 'Aspire Health Partners', 'https://aspirehealthpartners.com/', 'Florida’s largest behavioral health non-profit that provides a\n				full continuum of behavioral healthcare services across five Central Florida\n				counties: Brevard, Lake, Orange, Osceola and Seminole.', 70),
(104, 9, 'Osceola Regional Medical Center', 'https://osceolaregional.com/', 'Hospital', 80),
(105, 9, 'AdventHealth Kissimmee', 'https://www.adventhealth.com/hospital/adventhealth-kissimmee', 'Hospital', 90),
(106, 9, 'Saint Cloud Regional Medical Center', 'https://www.stcloudregional.com/', 'Hospital', 100),
(107, 9, 'Nemours Children\'s Health System', 'https://www.nemours.org/', 'Pediatric hospital', 110),
(108, 9, 'Arnold Palmer Hospital for Children', 'https://www.arnoldpalmerhospital.com/', 'Pediatric hospital', 120),
(109, 9, 'MedlinePlus', 'https://medlineplus.gov/', 'Health information from the U.S. National Library of Medicine', 130),
(110, 9, 'Free and Income Based Clinics in Kissimmee', 'https://www.freeclinics.com/cit/fl-kissimmee', '', 140),
(111, 10, 'DAREBEE', 'https://darebee.com/', 'Fitness hecho fácil - un recurso de fitness global independiente', 10),
(112, 10, 'Mercado de Seguros de Salud', 'https://www.cuidadodesalud.gov/es/', 'El sitio web oficial del Mercado de Seguros de Salud a Bajo\n				Costo. El mercado es una forma nueva de encontrar seguros de salud apropiados para\n				su presupuesto y que llenen sus necesidades. Con una aplicación usted puede ver\n				todas sus opciones y matricularse.', 20),
(113, 10, 'Clínica de Infecciones de Transmisión Sexual del Departamento de Salud\n				de Florida en el Condado de Osceola', 'http://osceola.floridahealth.gov/programs-and-services/infectious-disease-services/std/index.html', 'La Clínica de Infecciones de Transmisión Sexual del Departamento\n				de Salud de Florida en el Condado de Osceola ofrece servicios a un costo razonable o\n				de bajo costo a adultos y adolescentes, sin importar el estatus de ciudadanía. Los\n				servicios clínicos se proveen a todos los clientes, incluyendo adolescentes, a los\n				cuales se les asegura confidencialidad según la ley de Florida.', 30),
(114, 10, 'PlannedParenthood', 'https://www.plannedparenthood.org/es', 'Obtenga cuidado médico y respuestas sobre el embarazo, métodos\n				anticonceptivos, anticoncepción de emergencia, infecciones de transmisión sexual y\n				abortos.', 40),
(115, 10, 'Servicios para Personas con Discapacidades', 'https://www.usa.gov/disability-services', 'Encuentre información para personas con discapacidades, tal como:\n				beneficios y seguros, apoyo al cuidador, ayuda económica y servicios de apoyo,\n				programas de discapacidades locales y del gobierno, empleos y educación, beneficios\n				de discapacidad para veteranos, y derechos de discapacidad legales.', 50),
(116, 10, 'EL Departamento de Salud de Florida', 'http://osceola.floridahealth.gov/', 'El Departamento de Salud trabaja para proteger, promover y\n				mejorar la salud de todas las personas en Florida a través de esfuerzos integrados\n				entre el estado, el condado y la comunidad.', 60),
(117, 10, 'Aspire Health Partners', 'https://aspirehealthpartners.com/', 'La organización de salud del comportamiento sin fines de lucro\n				más grande de Florida provee un espectro completo de servicios de salud del\n				comportamiento a través de 5 condados de Florida Central: Brevard, Lake, Orange,\n				Osceola y Seminole.', 70),
(118, 10, 'Centro Médico Regional de Osceola', 'https://osceolaregional.com/', 'Hospital', 80),
(119, 10, 'AdventHealth Kissimmee', 'https://www.adventhealth.com/hospital/adventhealth-kissimmee', 'Hospital', 90),
(120, 10, 'Centro Médico Regional de Saint Cloud', 'https://www.stcloudregional.com/', 'Hospital', 100),
(121, 10, 'Sistema de Salud para Niños Nemours', 'https://www.nemours.org/', 'Hospital pediátrico', 110),
(122, 10, 'Hospital para Niños Arnold Palmer', 'https://www.arnoldpalmerhospital.com/', 'Hospital pediátrico', 120),
(123, 10, 'MedlinePlus', 'https://medlineplus.gov/spanish/', 'Información de salud de la Biblioteca Nacional de Medicina de\n				Estados Unidos', 130),
(124, 10, 'Clínicas de salud gratuitas y basadas en ingreso en Kissimmee', 'https://www.freeclinics.com/cit/fl-kissimmee', '', 140),
(125, 11, 'Section 8 Program', 'https://www.osceola.org/agencies-departments/human-services/housing/section-8-program/index.stml', 'The Section 8 Program is a federal rent subsidy which assists\n				participants with monthly rental payments.', 10),
(126, 11, 'Get Help If You’re Currently or About to Be Homeless', 'https://www.usa.gov/housing-help-audiences', 'If you’re facing homelessness, these tips can help you prepare\n				for and work through the situation.', 20),
(127, 11, 'Airbnb', 'https://www.airbnb.com/', 'Rent short or long term', 30),
(128, 11, 'Disaster Shelters', 'https://www.floridadisaster.org/planprepare/shelters/', 'Florida Division of Emergency Management', 40),
(129, 11, 'Osceola County Property Appraiser', 'https://www.property-appraiser.org/', 'The Property Appraiser assesses all property according to its\n				“just value”.', 50),
(130, 12, 'Programa de Sección 8', 'https://www.osceola.org/agencies-departments/human-services/housing/section-8-program/index.stml', 'El programa de Sección 8 es un subsidio federal de renta que\n				ayuda a los participantes con pagos mensuales para la renta.', 10),
(131, 12, 'Ayuda con asuntos de vivienda si eres indigente o a punto de ser\n				indigente', 'https://www.usa.gov/espanol/ayuda-asuntos-vivienda', 'Ayuda para encontrar vivienda para grupos con necesidades\n				específicas.', 20),
(132, 12, 'Airbnb', 'https://es.airbnb.com/', 'Renta a corto o a largo plazo', 30),
(133, 12, 'Refugios de Desastres', 'https://www.floridadisaster.org/planprepare/shelters/', 'División de Manejo de Emergencias de Florida', 40),
(134, 12, 'Tasador de Propiedades del Condado de Osceola', 'https://www.property-appraiser.org/', 'El Tasador de Propiedades evalúa todos los bienes de acuerdo a su\n				“valor justo”.', 50),
(135, 13, 'Legal Aid Society of Osceola', 'https://osceolabar.org/laso/', 'The Legal Aid Society of Osceola County was created by the\n				Osceola County Bar Association and currently helps residents of Osceola get access\n				to legal services.', 10),
(136, 13, 'Office of the Public Defender - 9th Judicial Circuit Orange and Osceola', 'http://www.myfloridapd.com/', 'The majority of their work focuses on representing people in\n				court. Their trained staff also connects clients with programs dealing with\n				substance abuse, anger management and a host of other issues aimed at keeping people\n				from returning to court.', 20),
(137, 13, 'Florida Department of Juvenile Justice (DJJ)', 'http://www.djj.state.fl.us/', 'The mission of DJJ is to increase public safety by reducing\n				juvenile delinquency through effective prevention, intervention and treatment\n				services that strengthen families and turn around the lives of troubled youth.', 30),
(138, 13, 'Seal and Expunge Process, Florida Department of Law Enforcement (FDLE)', 'https://www.fdle.state.fl.us/Seal-and-Expunge-Process/Seal-and-Expunge-Home.aspx', 'Seal or expunge criminal history record', 40),
(139, 13, 'Osceola County Courthouse', 'https://www.ninthcircuit.org/about/courthouses/osceola-county-courthouse', 'The facility houses the Courts, Court Administration, the Clerk\n				of Court, the State Attorney, the Public Defender, and ancillary services of the\n				Sheriff.', 50),
(140, 13, 'Florida Traffic Watch', 'https://floridatrafficwatch.org/', 'Driving License Notifications To Your Phone. Free service to the\n				residents of the following counties: Miami-Dade, Broward, Palm Beach, Orange', 60),
(141, 13, 'e-Notify, Florida’s Court Event Notification System', 'https://enotify.flcourts.org/', 'Text and e-mail reminders about your upcoming court events', 70),
(142, 13, 'Osceola County Sheriff\'s Office', 'https://www.osceolasheriff.org/', 'The Osceola County Sheriff\'s Office offers a wide range of\n				services. In addition to protecting life and property, the agency is responsible for\n				enforcing court orders, administering writs of execution, maintaining courtroom\n				security, investigating crimes, registering sex offenders, predators and felons in\n				our county and many other functions as designated by state law.', 80),
(143, 13, 'Osceola County Corrections', 'https://www.osceola.org/agencies-departments/corrections/index.stml', 'County jail', 90),
(144, 13, 'Florida Department of Corrections', 'http://www.dc.state.fl.us/', 'State prisons', 100),
(145, 13, 'Federal Bureau of Prisons', 'https://www.bop.gov/', 'Federal prisons', 110),
(146, 13, 'Sex Offender Registry Websites', 'https://www.fbi.gov/scams-and-safety/sex-offender-registry', 'State and national websites', 120),
(147, 14, 'Sociedad de Asistencia Legal de Osceola', 'https://osceolabar.org/laso/', 'La Sociedad de Asistencia Legal de Osceola fue creada por el\n				Colegio de Abogados del Condado de Osceola y actualmente asiste a los residentes de\n				Osceola a obtener acceso a servicios legales.', 10),
(148, 14, 'Oficina del Defensor Público – 9no Circuito Judicial: Orange y Osceola', 'http://www.myfloridapd.com/', 'La mayoría del trabajo que la Oficina del Defensor Público\n				realiza se enfoca en representar a la gente en la corte. El personal también conecta\n				los clientes con programas para el abuso de sustancias, manejo de la ira y muchos\n				otros problemas dirigidos a prevenir que las personas regresen a la corte.', 20),
(149, 14, 'Departamento de Justicia Juvenil de Florida (DJJ)', 'http://www.djj.state.fl.us/', 'La misión del DJJ es aumentar la seguridad pública al reducir la\n				delincuencia juvenil a través de la prevención efectiva, intervenciones y servicios\n				de tratamiento que fortalecen familias y transforman jóvenes problemáticos.', 30),
(150, 14, 'Proceso de Sellar y Eliminar, Agencia Policial de Florida (FDLE)', 'https://www.fdle.state.fl.us/Seal-and-Expunge-Process/Seal-and-Expunge-Home.aspx', 'Selle y elimine su historial criminal', 40),
(151, 14, 'Juzgado del Condado de Osceola', 'https://www.ninthcircuit.org/about/courthouses/osceola-county-courthouse', 'Las instalaciones alojan las cortes, la administración de las\n				cortes, el Secretario de la Corte, el Defensor Público y servicios auxiliares del\n				Sheriff.', 50),
(152, 14, 'Florida Traffic Watch', 'https://floridatrafficwatch.org/', 'Reciba notificaciones sobre su licencia de conducir en su móvil.\n				Servicio gratis para residentes de los siguientes condados: Miami-Dade, Broward,\n				Palm Beach, Orange.', 60),
(153, 14, 'e-Notify, Sistema de notificaciones de eventos en las cortes de Florida', 'https://enotify.flcourts.org/', 'Recordatorios por texto y correo electrónico sobre sus citas\n				pendientes en el tribunal', 70),
(154, 14, 'Oficina del Sheriff del Condado de Osceola', 'https://www.osceolasheriff.org/#', 'La Oficina del Sheriff del Condado de Osceola ofrece una gama de\n				servicios. En adición a proteger vidas y propiedades, la agencia es responsable por\n				enforzar órdenes de la corte, administrar órdenes de ejecución, mantener seguridad\n				en la sala de corte, investigar crímenes, registrar ofensores sexuales, depredadores\n				y felones en el condado y muchas otras funciones designadas por la ley.', 80),
(155, 14, 'Departamento de Corrección del Condado de Osceola', 'https://www.osceola.org/agencies-departments/corrections/index.stml', 'Cárcel del condado', 90),
(156, 14, 'Departamento de Corrección de Florida', 'http://www.dc.state.fl.us/', 'Prisiones estatales', 100),
(157, 14, 'Agencia Federal de Prisiones', 'https://www.bop.gov/', 'Prisiones federales', 110);
INSERT INTO `resources` (`id`, `section_id`, `name`, `link`, `description`, `sort_order`) VALUES
(158, 14, 'Buscadores de Delincuentes Sexuales y Depredadores', 'https://www.fbi.gov/scams-and-safety/sex-offender-registry', 'Sitios web estatales y nacional', 120),
(159, 15, 'SunRail', 'https://sunrail.com/', 'SunRail is a rail service with 16 stations through Volusia,\n				Seminole, Orange and Osceola counties.', 10),
(160, 15, 'Lynx', 'https://www.golynx.com/', 'Lynx buses provide daily public transportation for Orange,\n				Seminole and Osceola counties. Small portion of Lake and Polk counties are also\n				served.', 20),
(161, 15, 'Uber', 'https://www.uber.com/', 'Request a ride', 30),
(162, 15, 'Lyft', 'https://www.lyft.com/', 'Request a ride', 40),
(163, 15, 'Driver License and Motor Vehicle Service Centers', 'https://www.flhsmv.gov/locations/osceola/', 'Service centers in Osceola County', 50),
(164, 15, 'Osceola County Tax Collector', 'https://osceolataxcollector.org/', 'Driver license, driving skill test, and motor vehicle\n				registration', 60),
(165, 15, 'Used Car Buying Guide, Consumer Reports', 'https://www.consumerreports.org/buying-a-car/used-car-buying-guide/', 'Used vehicles are often the best values you\'ll find in the\n				automotive market.', 70),
(166, 15, 'Guide to Buying a New Car, Consumer Reports', 'https://www.consumerreports.org/buying-a-car/new-car-buying-guide/', 'Consumer Reports can help guide you through the new car buying\n				experience. They give you the essential information you need to choose, buy,\n				finance, and maintain a new car.', 80),
(167, 15, 'Kelley Blue Book', 'https://www.kbb.com/', 'KBB.com gives you everything you need to research a new,\n				certified (CPO) or used car, compare cars, find cars for sale and make a\n				well-informed decision.', 90),
(168, 15, 'The Best Cheap Car Insurance for 2020', 'https://www.nerdwallet.com/blog/insurance/best-cheap-car-insurance/', 'One of the best ways to get cheap car insurance is by comparing\n				car insurance quotes and companies.', 100),
(169, 16, 'SunRail', 'https://sunrail.com/es/', 'El SunRail es un servicio ferroviario con 16 estaciones en los\n				condados de Volusia, Seminole, Orange y Osceola.', 10),
(170, 16, 'Lynx', 'https://www.golynx.com/', 'Los autobuses de Lynx proveen transportación pública diaria para\n				los condados de Orange, Seminole y Osceola. Porciones pequeñas de los condados de\n				Lake y Polk también son servidas.', 20),
(171, 16, 'Uber', 'https://www.uber.com/us/es/', 'Obtenga un viaje ahora', 30),
(172, 16, 'Lyft', 'https://www.lyft.com/', 'Obtenga un viaje ahora', 40),
(173, 16, 'Licencia de Conducir y Centros de Servicio de Vehículos Motorizados', 'https://www.flhsmv.gov/locations/osceola-es/', 'Centros de servicio en el Condado de Osceola', 50),
(174, 16, 'Recaudador de Impuestos del Condado de Osceola', 'https://osceolataxcollector.org/', 'Licencia de conducir, examen de destrezas de conducir, y\n				registración de veículos de motor', 60),
(175, 16, 'Guía para comprar un auto usado, Consumer Reports', 'https://www.consumerreports.org/buying-a-car/used-car-buying-guide/', 'Los vehículos usados a menudo ofrecen el mejor valor que puede\n				encontrar en el mercado automotriz.', 70),
(176, 16, 'Guía para comprar un auto nuevo, Consumer Reports', 'https://www.consumerreports.org/buying-a-car/new-car-buying-guide/', 'Consumer Reports le puede ayudar a guiarle através de su\n				experiencia de comprar un auto. Ellos les dan la información esencial que usted\n				necesita para escoger, comprar, financiar y mantener un auto nuevo.', 80),
(177, 16, 'Kelley Blue Book', 'https://www.kbb.com/', 'KBB.com ofrece todo lo que necesita para investigar un auto\n				nuevo, certificado (CPO) o usado, comparar autos, encontrar autos en venta y tomas\n				desiciones informadas.', 90),
(178, 16, 'El mejor seguro de autos más barato del 2020', 'https://www.nerdwallet.com/blog/insurance/best-cheap-car-insurance/', 'Una de las mejores formas de obtener un seguro de auto barato es\n				comparar cotizaciones y compañías.', 100),
(179, 17, 'Amtrak', 'https://www.amtrak.com/', 'The National Railroad Passenger Corporation, Amtrak, is a\n				national rail passenger operator.', 10),
(180, 17, 'Greyhound', 'https://www.greyhound.com/', 'Affordable long distance travel in North America', 20),
(181, 17, 'RedCoach', 'https://www.redcoachusa.com/', 'RedCoach offers three different routes that stop at nearly every\n				key city in the Sunshine State as well as Atlanta, in Georgia. You can reach Miami,\n				Jacksonville, West Palm Beach, Tampa, Gainesville, Tallahassee, Fort Pierce,\n				Orlando, Fort Myers, Ocala, and Fort Lauderdale, to name a few.', 30),
(182, 17, 'USA Rest Stop Locator', 'http://www.usareststops.com/', 'Easily find all rest stops through the entire United States on\n				your iOS or Android device.', 40),
(183, 17, 'Mobile Passport Control', 'https://www.cbp.gov/travel/us-citizens/mobile-passport-control', 'Mobile Passport Control streamlines your U.S. Customs and Border\n				Protection processing experience. Just fill out your profile and answer CBP’s\n				questions – then go straight to the “Mobile Passport Control” lane at the airport!', 50),
(184, 17, 'Smart Traveler Enrollment Program(STEP)', 'https://step.state.gov/step/', 'The Smart Traveler Enrollment Program (STEP) is a free service to\n				allow U.S. citizens and nationals traveling and living abroad to enroll their trip\n				with the nearest U.S. Embassy or Consulate.', 60),
(185, 18, 'Amtrak', 'https://espanol.amtrak.com/', 'Amtrak, una Corporación Nacional de Ferrocarriles de Pasajeros,\n				es un operador nacional de ferrocarriles de pasajeros.', 10),
(186, 18, 'Greyhound', 'https://www.greyhound.com/', 'Viajes económicos a larga distancia en América del Norte', 20),
(187, 18, 'RedCoach', 'https://www.redcoachusa.com/es/', 'RedCoach afrece tres rutas differentes con paradas en casi todas\n				las ciudades claves en Florida, así como también Atlanta, Georgia. Puedes llegar a\n				Miami, Jacksonville, West Palm Beach, Tampa, Gainesville, Tallahassee, Fort Pierce,\n				Orlando, Fort Myers, Ocala, y Fort Lauderdale, entre otras ciudades.', 30),
(188, 18, 'Localizador de paradas de descanso en Estados Unidos', 'http://www.usareststops.com/', 'Encuentre todas las paradas de descanso en todo el país de\n				Estados Unidos en su dispositivo móvil iOS o Android.', 40),
(189, 18, 'Control de Pasaporte Móvil', 'https://www.cbp.gov/travel/us-citizens/mobile-passport-control', 'Control de Pasaporte Móvil optimiza su experiencia del\n				procesamiento de las Aduanas y Protección Fronteriza de Estados Unidos (CBP).\n				Simplemente llene su perfil y conteste las preguntas del CBP. Luego vaya a la fila\n				en el aeropuerto rotulada “Mobile Passport Control”.', 50),
(190, 18, 'Smart Traveler Enrollment Program(STEP)', 'https://step.state.gov/step/', 'EL Programa de Inscripción de Smart Traveler es un servicio\n				gratuito que les permite a los ciudadanos y nacionales estadounidenses que viajan y\n				viven en el extranjero inscribir su viaje con la embajada o consulado estadounidense\n				más cercanos.', 60),
(191, 19, 'IDignity Osceola', 'https://osceola.idignity.org/', 'IDignity provides assistance in obtaining Florida ID cards and\n				licenses, birth certificates, Social Security cards, replacement citizenship or\n				immigration records and other documents needed to obtain an ID/license. There is no\n				charge for our services to those in need.', 10),
(192, 19, 'Vote Osceola', 'https://www.voteosceola.com/en-us/Voter-Information/Check-Your-Voter-Status', 'Voter Information in Osceola County', 20),
(193, 19, 'Florida Online Voter Registration System', 'https://registertovoteflorida.gov/', 'This system can be used to submit an application online for new\n				registration or to make changes to your existing registration record or to prefill a\n				voter registration application form.', 30),
(194, 19, 'Vote.gov', 'https://vote.gov/', 'Register to vote', 40),
(195, 19, 'Osceola County Tax Collector', 'https://osceolataxcollector.org/', 'Florida birth certificates', 50),
(196, 19, 'Office of Vital Statistics, Florida Department of Health in Osceola\n				County', 'http://osceola.floridahealth.gov/certificates/index.html', 'Birth certificates, death certificates', 60),
(197, 19, 'Social Security Administration', 'https://www.ssa.gov/', 'Social security card', 70),
(198, 19, 'U.S. Passport', 'https://travel.state.gov/content/travel/en/passports.html/', 'Apply for or renew your passport', 80),
(199, 19, 'Other vital documents', 'https://www.usa.gov/replace-vital-documents', 'Driver licence, ID card, social security card, Medicaid card,\n				U.S. passport, permanent resident (green) card, U.S. military ID', 90),
(200, 20, 'IDignity Osceola', 'https://osceola.idignity.org/', 'IDignity provee asistencia para obtener licencias y tarjetas de\n				identificación de Florida, certificados de nacimiento, tarjetas ded Seguro Social,\n				reemplazo de documentos de ciudadanío o inmigración y otros documentos necesarios\n				para obtener licencias y tarjetas de identificación. Los servicios son gratuitos\n				para las personas necesitadas.', 10),
(201, 20, 'Vote Osceola', 'https://www.voteosceola.com/es-us/Informacin-del-Elector/Verifique-Su-Estatus-Electoral', 'Información sobre votqantes en el Condado de Osceola', 20),
(202, 20, 'Sistema de solicitud de inscripción como votante de Florida', 'https://registertovoteflorida.gov/', 'Este sistema se puede utilizar para subministrar en línea una\n				solicitud de inscripción como votante, para actualizar un registro de inscripción o\n				para rellenar un formulario de solicitud de inscripción como votante.', 30),
(203, 20, 'Vote.gov en Español', 'https://vote.gov/es/', 'Inscríbase para votar', 40),
(204, 20, 'Recaudador de Impuestos del Condado de Osceola', 'https://osceolataxcollector.org/', 'Certificados de nacimentos de Florida', 50),
(205, 20, 'Oficina de Asuntos Demográficos, Departamento de Salud de Florida en el\n				Condado de Osceola', 'http://osceola.floridahealth.gov/certificates/index.html', 'Certificados de nacimentos, certificados de defunción', 60),
(206, 20, 'Administración del Seguro Social', 'https://www.ssa.gov/espanol/', 'Tarjeta de seguro social', 70),
(207, 20, 'Pasaporte de Estados Unidos', 'https://travel.state.gov/content/travel/es/pasaportes.html', 'Aplique or renueve su pasaporte', 80),
(208, 20, 'Otros documentos importantes', 'https://www.usa.gov/replace-vital-documents', 'Licencia de conducir, identificación, tarjeta de seguro social,\n				tarjeta de Medicaid, pasaporte de Estados Unidos, tarjeta de residente permanente\n				(green card), tarjeta de identificación militar de Estados Unidos', 90),
(209, 21, 'The Osceola Library System', 'http://www.osceolalibrary.org/', 'The Library has six branches, a collection of over 275,000\n				volumes, and serves over 120,000 library customers.', 10),
(210, 21, 'The Right Service at the Right Time', 'http://rightservicefl.org', 'Search for a service in all counties', 20),
(211, 21, 'Change of Address', 'https://moversguide.usps.com/mgo/disclaimer', 'United States Postal Service (USPS)', 30),
(212, 21, '2-1-1 Help Line, Heart of Florida United Way', 'https://www.hfuw.org/gethelp/', '2-1-1 is free and completely confidential, available 24/7. You\n				can access 2-1-1 by phone, email, chat or text (just text your zip code to 898-211).\n				Reaching out will get you connected to a multilingual 2-1-1 specialist in your area\n				who can put you in touch with local organizations providing critical services to\n				improve and save lives.', 40),
(213, 21, 'National Suicide Prevention Lifeline', 'https://suicidepreventionlifeline.org/', 'Call 1-800-273-8255. The National Suicide Prevention Lifeline is\n				a United States-based suicide prevention network of 161 crisis centers that provides\n				a 24/7, toll-free hotline available to anyone in suicidal crisis or emotional\n				distress.', 50),
(214, 21, 'National Domestic Violence Hotline', 'https://www.thehotline.org/', 'Call 1-800-799-7233, 1-800-787-3224 (TTY). Advocates are\n				available 24/7 in more than 200 languages. All calls are free and confidential.', 60),
(215, 21, 'MyFlorida', 'http://www.myflorida.com/', 'The Official Page for Sunshine State Government', 70),
(216, 21, 'login.gov', 'https://login.gov/', 'Simple, secure access to government services online', 80),
(217, 22, 'El Sistema de Bibliotecas de Osceola', 'http://www.osceolalibrary.org/', 'La Biblioteca cuenta con seis sucursales, una colección de más de\n				275,000 volúmenes, y atiende a más de 120,000 clientes de la biblioteca.', 10),
(218, 22, 'El Servicio Adecuado en el Momento Adecuado', 'http://rightservicefl.org/', 'Busca servicios en todos los condados', 20),
(219, 22, 'Cambie su dirección', 'https://moversguide.usps.com/mgo/disclaimer', 'Servicio Postal de Estados Unidos (USPS)', 30),
(220, 22, 'Línea de ayuda 2-1-1, Heart of Florida United Way', 'https://www.hfuw.org/gethelp/', 'El 2-1-1 es gratis, completamente confidencial y disponible 24/7.\n				Puede acceder 2-1-1 por teléfono, correo electrónico, chat o texto (simplemente\n				envie su código postal al 898-211). Al contactarse se conectará con un especialista\n				2-1-1 multilingual en su área que le puede poner en contacto con organizaciones\n				locales que proveen servicios críticos que mejoran y salvan vidas.', 40),
(221, 22, 'Red Nacional de Prevención del Suicidio', 'https://suicidepreventionlifeline.org/help-yourself/en-espanol/', 'Llame 1-888-628-9454. Red Nacional de Prevención del Suicidio es\n				una red de prevención basada en los Estados Unidos que cuenta con 161 centros de\n				crisis que proveen una línea directa gratuita disponible 24/7 a cualquier persona en\n				crisis de suicidio o aflicción emocional.', 50),
(222, 22, 'Línea Telefónica de Ayuda contra la Violencia Doméstica', 'https://espanol.thehotline.org/', 'Llame 1-800-799-7233, 1-800-787-3224 (TTY). Los asesores están\n				disponibles 24/7 en más de 200 lenguages. Todas las llamadas son gratuitas y\n				confidenciales.', 60),
(223, 22, 'MyFlorida', 'http://www.myflorida.com/', 'La Página Oficial de Gobierno del Estado del Sol', 70),
(224, 22, 'login.gov', 'https://login.gov/es/', 'Acceso simple y seguro a los servicios en línea del Gobierno', 80);

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(50) NOT NULL COMMENT 'lowercase a-z, 0-9, hyphen; e.g. education',
  `lang` char(2) NOT NULL COMMENT 'en or es',
  `name` varchar(100) NOT NULL COMMENT 'heading shown on the page',
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT 'lower numbers first'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `slug`, `lang`, `name`, `sort_order`) VALUES
(1, 'social', 'en', 'Social Services', 10),
(2, 'social', 'es', 'Servicios Sociales', 10),
(3, 'education', 'en', 'Education', 20),
(4, 'education', 'es', 'Educación', 20),
(5, 'finances', 'en', 'Finances', 30),
(6, 'finances', 'es', 'Finanzas', 30),
(7, 'employment', 'en', 'Employment', 40),
(8, 'employment', 'es', 'Empleo', 40),
(9, 'health', 'en', 'Health', 50),
(10, 'health', 'es', 'Salud', 50),
(11, 'housing', 'en', 'Housing', 60),
(12, 'housing', 'es', 'Vivienda', 60),
(13, 'legal', 'en', 'Legal Services', 70),
(14, 'legal', 'es', 'Servicios Legales', 70),
(15, 'transportation', 'en', 'Transportation', 80),
(16, 'transportation', 'es', 'Transportación', 80),
(17, 'travel', 'en', 'Travel', 90),
(18, 'travel', 'es', 'Viajar', 90),
(19, 'vitaldocs', 'en', 'Vital Documents', 100),
(20, 'vitaldocs', 'es', 'Documentos Importantes', 100),
(21, 'miscellaneous', 'en', 'Miscellaneous', 110),
(22, 'miscellaneous', 'es', 'Misceláneos', 110);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `resources`
--
ALTER TABLE `resources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_resources_section_sort` (`section_id`,`sort_order`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_sections_slug_lang` (`slug`,`lang`),
  ADD KEY `idx_sections_sort` (`sort_order`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `resources`
--
ALTER TABLE `resources`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=225;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `resources`
--
ALTER TABLE `resources`
  ADD CONSTRAINT `fk_resources_section` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
